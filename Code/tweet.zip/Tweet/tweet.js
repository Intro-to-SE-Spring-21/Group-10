var newTweet = document.getElementById("tweet-body");
var tweets = document.getElementById("tweets");
var existingTweets = ['Example tweet.'];

window.onload = function() {
    getTweets();
}

function createTweet() {
    document.getElementById("display-create").hidden = false;
}

function hideForm() {
    document.getElementById("display-create").hidden = true;
}

function getTweets() {
    for (var i = 0; i < existingTweets.length; i++) {
        var tweet = existingTweets[i];
        var li = document.createElement('li');
        li.className = 'collection-item';
        li.appendChild(document.createTextNode(tweet));
        tweets.appendChild(li); 
    }
    console.log(existingTweets);
}

function storeTweet(tweet) {

    existingTweets.push(tweet);
    console.log(existingTweets);
}

function addTweet() {
    if (newTweet.value === '') {
        alert("Please type something to post.");
    } else {
        storeTweet(newTweet.value);
        const li = document.createElement("li");
        li.className = "collection-item";
        li.appendChild(document.createTextNode(newTweet.value));
        tweets.appendChild(li);
        console.log(newTweet.value);
        getTweets();
        newTweet.value = '';
    }
}